Bluetooth stack bit rate changer + aptX & aptX-HD Enabler Module
Possibly some files are not necessary, but who cares )
Tested on Redmi 4X.

## Requirements ##
- Redmi 4x??? Try it and let me know.
- MIUI 10 or any Android >=7

BT stack is modified in the way so it uses:
- Dual Channel for any audio connection
- Maximum bitrate depending on GitHub branch used. Test it on your headphones. Normally 484 kbit/s is OK with any headphones, personally I use 576 kbit/s without any problems.


